package mina.app.broadcastreciever;


import android.util.Log;
import android.widget.Toast;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;


import java.util.LinkedList;

public class TickerViewModel extends ViewModel {

    MutableLiveData<LinkedList<Stock>> tickers;
    private MutableLiveData<Stock> tickerData;
    LinkedList<Stock> history = new LinkedList<>();
    MutableLiveData<Integer> clicked;

    public LiveData<LinkedList<Stock>> getTickers() {
        if (tickers == null) {
            tickers = new MutableLiveData<>();
            loadTickers();
        }
        return tickers;
    }

    public void addTicker(Stock t){
        LinkedList<Stock> stock = tickers.getValue();
        stock.add(t);
        tickers.setValue(stock);
    }

    private void loadTickers() {
        LinkedList<Stock> lTickers = new LinkedList<Stock>();
        lTickers.add(new Stock("BAC"));
        lTickers.add(new Stock("AAPL"));
        lTickers.add(new Stock("DIS"));

        tickers.setValue(lTickers);
    }


    public MutableLiveData<Integer> getClicked() {
        if (clicked == null) {
            clicked = new MutableLiveData<>();
        }
        return  clicked;
    }

    public void setClicked(int pos) {
        if (clicked == null) {
            clicked = new MutableLiveData<>();
        }
        clicked.setValue(pos);

    }
}

